//
//  ViewController.swift
//  RSSExample
//
//  Created by Tops on 4/3/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit

class ViewController: UIViewController, XMLParserDelegate , UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var newsTable: UITableView!
   
    var btn = newsCell()
    
    
    let urlStr = "http://feeds.feedburner.com/ndtvmovies-latest?format=xml"
    var newsData = [[String:Any]]()
    var news = [String:Any]()
    var PreElementName = ""
    var strContent = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //btn.readMorebtn.addTarget(self, action: #selector(ViewController.tableView(_:didSelectRowAt:)), for: .touchUpInside)
        self.ReadRss()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func ReadRss(){
        do {
        let url = URL(string: urlStr)
        let data = try Data.init(contentsOf: url!)
        let xmlParser = XMLParser(data: data)
        xmlParser.delegate = self
        print(data.count)
            if xmlParser.parse(){
                print("Data Reading Complete")
            }
            else{
                print("Data not read")
            }
        
        }
        catch let er as NSError{
            print("Error: ",er)
        
        }
    
    }
    
    func parserDidStartDocument(_ parser: XMLParser) {
        newsData = [[String:Any]]()
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if elementName == "item"{
            PreElementName = elementName
            news = [String:Any]()
            print("Start Element is:", elementName)
        }
        else{
            if elementName == "guid" || elementName == "title" || elementName == "description" || elementName == "link" || elementName == "updateAt" || elementName == "pubData" || elementName == "StoryImage"{
                print("\t Start Element is: ", elementName)
                strContent = ""
            }
        }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        strContent += string
        print("Data is : ", strContent)
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == PreElementName{
            print("End element is: ", elementName)
            newsData.append(news)
            PreElementName = ""
        }
        else{
            if elementName == "guid" || elementName == "title" || elementName == "description" || elementName == "link" || elementName == "updateAt" || elementName == "pubData" || elementName == "StoryImage" {
            
                if elementName == "StoryImage" {
                    do{
                        let imgdata = try Data.init(contentsOf: URL(string: strContent)!)
                        news[elementName] = imgdata
                    }
                    catch{
                    
                    }
                }
                else{
                    print("\t End Element is: ", elementName)
                    news[elementName] = strContent
                }
                    strContent = ""
            }
        
        }
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        print(newsData)
        newsTable.reloadData()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsData.count    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "news") as! newsCell
        
        news = newsData[indexPath.row]
        cell.lbltitle.text = news["title"] as! String?
        cell.imgView.image = UIImage(data: news["StoryImage"] as! Data)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let _selectednews = newsData[indexPath.row]
      //  print("Selected news:",_selectednews["link"]!)
        
        let newsDetailView = self.storyboard?.instantiateViewController(withIdentifier: "newsDetailView") as! newsDetailViewController
        
        
        newsDetailView.url = _selectednews["link"] as! String
        newsDetailView.lblTitl = _selectednews["title"] as! String
        
        print("Selected url:",newsDetailView.url)
        self.navigationController?.pushViewController(newsDetailView, animated: true)
        
    }
    
    
 
}

class newsCell: UITableViewCell{

    @IBOutlet var imgView:UIImageView!
    @IBOutlet weak var lbltitle: UILabel!

    @IBOutlet var readMorebtn:UIButton!


}


class newsDetailViewController: UIViewController{

    
    var url:String = ""
    
    var lblTitl = ""
   
    @IBOutlet weak var txtURL: UITextField!

    @IBOutlet weak var lbltitle: UILabel!
   
    @IBOutlet weak var webViewControl: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    self.txtURL.text = url
    self.lbltitle.text = lblTitl
    let loadUrl = URL(string: url)
    let request = URLRequest(url: loadUrl!)
    let con = NSURLConnection(request: request, delegate: self)
    con?.start()
    self.webViewControl.loadRequest(request)
    self.resignFirstResponder()
        
        
    }

}
